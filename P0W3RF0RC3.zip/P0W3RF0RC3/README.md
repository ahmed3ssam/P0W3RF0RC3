# P0W3RF0RC3
P0W3RF0RC3 is a post-exploitation and lateral movements framework  
![image](c2.png)

## Documentation

[ReadTheDocs](https://picklec2.readthedocs.io/)

## Overview

P0W3RF0RC3 is a simple C2 framework written in python3 used to help the community in Penetration Testers in their red teaming engagements.  

P0W3RF0RC3 has the ability to import your own PowerShell module for Post-Exploitation and Lateral Movement or automate the process.  


## Features 

There is a one implant for the beta version which is powershell.   

1. P0W3RF0RC3 is fully encrypted communications, protecting the confidentiality and integrity of the C2 traffic even when communicating over HTTP.

2. P0W3RF0RC3 can handle multiple listeners and implants with no issues

3. P0W3RF0RC3 supports anyone who would like to add his own PowerShell Module

## Future Features

In the up coming updates pickle will support:   

1. Go Implant

2. Powershell-Less Implant that don’t use System.Management.Automation.dll.

3. Malleable C2 Profile will be supported.

4. HTTPS communications will be supported. NOTE: Even HTTP communications is fully encrypted.

## Install

```bash
git clone https://github.com/xRET2pwn/P0W3RF0RC3.git
cd P0W3RF0RC3
sudo apt install python3 python3-pip
python3 -m pip install -r requirements.txt
./run.py
```

