from colorama import Fore, Style



def cyan(text):
	return (Fore.CYAN + text + Style.RESET_ALL)


def yellow(text):
	return (Fore.YELLOW + text + Style.RESET_ALL)



def green(text):
	return (Fore.GREEN + text + Style.RESET_ALL)


def red(text):
        return (Fore.RED + text + Style.RESET_ALL)


def blue(text):
        return (Fore.BLUE + text + Style.RESET_ALL)



